public class Brigand extends Humain implements Capture {


    public Brigand(String nomHumain) {
        super(nomHumain);
        this.nomHumain = nomHumain;
        this.boisson = boisson;

    }

    private String nomHumain;
    private String boisson = "eau";


    String look = "méchant";
    static int damesEnlevees;
    @Override
    public String parler(String texte) {
        System.out.println(nomHumain + " - " + texte);
        return nomHumain;
    }
    @Override
    public String quelEstTonNom() {
        System.out.println("mon nom est " + nomHumain + " le " + look);
        return nomHumain + look;
    }
    @Override
    public void getBoisson() {
        System.out.println("Ma boisson préférée est " + boisson);
    }
    @Override
    public Boolean capturer() {
        System.out.println("Ahah tu es mienne désormais" + nomDame);
        damesEnlevees++;
        System.out.println("J'ai enlevé jusqu'ici" + damesEnlevees + "dames");
        if (brigandenPrison == true) {

            System.out.println("Damned,je suis fait!" + nomCowboy + ", tu m’as eu !");

        }
        return null;
    }

}
