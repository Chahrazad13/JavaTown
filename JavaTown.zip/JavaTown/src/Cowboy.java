public class Cowboy extends Humain implements Capture {

    int popularite = 0;
    String adjectif = "vaillant ";
    private String boisson = "eau";
    private String nomHumain;
   private int recompense = 0;
   static int captureCounter = 0;

    public Cowboy(String nomHumain) {
        super(nomHumain);
        this.nomHumain = nomHumain;
        this.boisson = boisson;

    }
   @Override
  public Boolean capturer() {
     if (false == brigandenPrison) {
       captureCounter++;
         recompense += 100;
         System.out.println("recompense : " + recompense);
          return brigandenPrison;

     }
return null;
  }

    public void tirer() {
        System.out.println("le " + adjectif + nomCowboy + " tire sur le méchant " + nomBrigand + " .PAN !");
    }


    @Override
    public String parler(String texte) {
        System.out.println(nomHumain + " - " + texte);
        return nomHumain;
    }

    @Override
    public String quelEstTonNom() {
        System.out.println("mon nom est " + nomHumain);
        return nomHumain;
    }

    @Override
    public void getBoisson() {
        System.out.println("Ma boisson préférée est " + boisson);
    }
}

