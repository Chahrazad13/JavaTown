public interface Capture {

    abstract Boolean capturer();
   String nomDame = "Ginette";
   String nomCowboy = "Lucky Luke";
   String nomBrigand = "Billy the Kid";
    Boolean brigandenPrison = false;




}
