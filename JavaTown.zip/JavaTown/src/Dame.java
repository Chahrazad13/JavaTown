public class Dame extends Humain {
    public Dame(String nomHumain) {
        super(nomHumain);
        this.nomHumain = nomHumain;
        this.boisson = boisson;
    }

   private String nomHumain;
   private String boisson = "eau";

    String couleur;

    boolean islibre;

    {
        islibre = true;
    }


    @Override
    public String parler(String texte) {
        System.out.println(nomHumain + " - " + texte);
        return nomHumain;
    }

    @Override
    public String quelEstTonNom() {
     System.out.println("mon nom est miss " + nomHumain);
        return nomHumain;
    }

    @Override
    public void getBoisson() {
        System.out.println("Ma boisson préférée est " + boisson);
    }

    public void seFaireKidnapper() {
        System.out.println(" Omg je me suis faite kidnapper");
    }

    public void seFaireliberer() {
        System.out.println(" Merci Cowboy ");
    }

    public void changerLaRobe() {
        System.out.println("Regardez ma nouvelle robe" + couleur + "!");
    }

}
