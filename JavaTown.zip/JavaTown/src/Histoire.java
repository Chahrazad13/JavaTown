public class Histoire {

    public static void main(String[] args) {


        Brigand lol = new Brigand("kartouche");
        Cowboy lou = new Cowboy("Bifteck");
lol.capturer();
lou.capturer();

    }
}

