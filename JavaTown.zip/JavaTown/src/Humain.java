

public abstract class Humain {
  private  String boisson = "eau";
   private String nomHumain;

    public Humain(String nomHumain) {
        this.nomHumain = nomHumain;
        this.boisson = boisson;

    }
    public String parler(String texte){
        System.out.println(nomHumain + " - " + texte);
        return nomHumain;
    }

    public String quelEstTonNom(){
        System.out.println(nomHumain);
        return nomHumain;
    }

    public void getBoisson(){
        System.out.println("Ma boisson préférée est "+ boisson);
    }



}

